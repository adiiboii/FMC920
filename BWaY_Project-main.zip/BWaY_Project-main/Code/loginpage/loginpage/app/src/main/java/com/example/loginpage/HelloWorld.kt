package com.example.loginpage

fun main(args: Array<String>)
{
    var a = 10
    var b = 20
    var c = a + b
    println(c)
}