package com.example.loginpage

fun main(args: Array<String>)
{
   var a: Boolean = true
    var b: Char = 'R'
    var c: Byte = 12
    var e: Int = 12345
}