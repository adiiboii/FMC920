package com.example.loginpage

fun main(args: Array<String>)
{
var a:String = "Hello Kotlin"

    print(a)
}